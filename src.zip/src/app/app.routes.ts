import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login';
import { LandingComponent } from './pages/landing/landing';
import { DashboardAdmin } from './pages/dashboard-admin/dashboard-admin';
import { DashboardEmpresa } from './pages/dashboard-empresa/dashboard-empresa';
import { DashboardUsuario } from './pages/dashboard-usuario/dashboard-usuario';
import { OfertasComponent } from './pages/ofertas/ofertas';
import { DetalleOferta } from './pages/detalle-oferta/detalle-oferta';
import { PerfilUsuario } from './pages/perfil-usuario/perfil-usuario';
import { PerfilEmpresa } from './pages/perfil-empresa/perfil-empresa';
import { Postulaciones } from './pages/postulaciones/postulaciones';
import { Foro } from './pages/foro/foro';
import { GestionUsuarios } from './pages/gestion-usuarios/gestion-usuarios';
import { GestionEmpresas } from './pages/gestion-empresas/gestion-empresas';
import { GestionVacantes } from './pages/gestion-vacantes/gestion-vacantes';
import { Moderacion } from './pages/moderacion/moderacion';
import { GestionOfertas } from './pages/gestion-ofertas/gestion-ofertas';
import { authGuard }    from './guards/auth-guard';
import { adminGuard } from './guards/admin-guard';
import { empresaGuard } from './guards/empresa-guard';
import { candidatoGuard } from './guards/usuario-guard';
import { PerfilEmpresaPublico } from './pages/perfil-empresa-publico/perfil-empresa-publico';
import { DetalleCandidato } from './pages/detalle-candidato/detalle-candidato';
import { GestionForo } from './pages/gestion-foro/gestion-foro';
import { Recursos } from './pages/recursos/recursos';

export const routes: Routes = [
  { path: '', redirectTo: 'landing', pathMatch: 'full' },
  { path: 'landing', component: LandingComponent },
  { path: 'login', component: LoginComponent },
  { path: 'dashboard-admin', component: DashboardAdmin },
  { path: 'dashboard-empresa', component: DashboardEmpresa },
  { path: 'dashboard-usuario', component: DashboardUsuario },
  { path: 'ofertas', component: OfertasComponent },
  { path: 'ofertas/:id', component: DetalleOferta },
  { path: 'perfil-empresa', component: PerfilEmpresa },
  { path: 'postulaciones', component: Postulaciones },
  { path: 'foro', component: Foro },
  { path: 'gestion-usuarios', component: GestionUsuarios },
  { path: 'gestion-empresas', component: GestionEmpresas },
  { path: 'moderacion', component: Moderacion },
  { path: 'ofertas', component: OfertasComponent },
  { path: 'ofertas/:id', component: DetalleOferta },
  { path: 'gestion-ofertas', component: GestionOfertas, canActivate: [authGuard, empresaGuard] },
  { path: 'dashboard-usuario', component: DashboardUsuario, canActivate: [authGuard, candidatoGuard] },
  { path: 'postulaciones', component: Postulaciones, canActivate: [authGuard, candidatoGuard] },
  { path: 'perfil-usuario', component: PerfilUsuario, canActivate: [authGuard, candidatoGuard] },
  { path: 'recursos', component: Recursos },
  { path: 'foro', component: Foro, canActivate: [authGuard] },
  { path: 'dashboard-empresa', component: DashboardEmpresa, canActivate: [authGuard, empresaGuard] },
  { path: 'perfil-empresa', component: PerfilEmpresa, canActivate: [authGuard, empresaGuard] },
  { path: 'dashboard-admin', component: DashboardAdmin, canActivate: [authGuard, adminGuard] },
  { path: 'gestion-usuarios', component: GestionUsuarios, canActivate: [authGuard, adminGuard] },
  { path: 'gestion-empresas', component: GestionEmpresas, canActivate: [authGuard, adminGuard] },
  { path: 'gestion-vacantes', component: GestionVacantes, canActivate: [authGuard, adminGuard] },
  { path: 'moderacion', component: Moderacion, canActivate: [authGuard, adminGuard] },
  { path: 'gestion-foro', component: GestionForo, canActivate: [authGuard, adminGuard] },
  { path: 'perfil-empresa-publico/:id', component: PerfilEmpresaPublico },  { path: 'detalle-candidato/:userId/:applicationId/:jobPostId', component: DetalleCandidato },  { path: 'detalle-candidato', component: DetalleCandidato },
  { path: '**', redirectTo: 'login' }
];